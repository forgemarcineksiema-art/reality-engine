import hashlib
import json
import pathlib
import subprocess
import sys

root = pathlib.Path(__file__).resolve().parents[2]
out = root / 'build/m05-two-methods'
exe = root / 'build/msvc/RelWithDebInfo/reality_two_methods_tests.exe'
window = root / 'build/msvc/RelWithDebInfo/reality_traversal.exe'
records = {}
for method in ('repair', 'detour'):
    checkpoint, expected, actual = [out / f'final-{method}-{name}.save'
                                    for name in ('checkpoint', 'expected', 'actual')]
    subprocess.run([str(exe), 'checkpoint', method, str(checkpoint), str(expected)], check=True, timeout=8)
    original = checkpoint.read_bytes()
    subprocess.run([str(exe), 'continue', method, str(checkpoint), str(actual)], check=True, timeout=8)
    assert expected.read_bytes() == actual.read_bytes()
    assert checkpoint.read_bytes() == original
    records[method] = {'checkpoint_sha256': hashlib.sha256(original).hexdigest(),
                       'final_sha256': hashlib.sha256(actual.read_bytes()).hexdigest()}
    subprocess.run([sys.executable, str(root / 'tools/test_practice_native.py'),
                    '--exe', str(window), '--two-methods', '--method', method,
                    '--output', str(out / f'final-native-{method}')], check=True)

old_checkpoint = out / 'profile-checkpoint.save'
old_expected = out / 'profile-expected.save'
new_actual = out / 'before-optimization-continued.save'
subprocess.run([str(exe), 'continue', 'detour', str(old_checkpoint), str(new_actual)], check=True, timeout=8)
assert new_actual.read_bytes() == old_expected.read_bytes(), 'pre-optimization save diverged'
records['pre_optimization_save'] = {'identical': True,
                                   'sha256': hashlib.sha256(new_actual.read_bytes()).hexdigest()}
with (out / 'final-continuation.json').open('x', encoding='utf-8') as target:
    json.dump(records, target, indent=2)
subprocess.run([sys.executable, str(root / 'tools/start_practice_playtest.py'),
                '--two-methods', '--smoke-test'], check=True, timeout=20)
print('PASS retained continuations, pre-optimization save, both native methods and launcher')
