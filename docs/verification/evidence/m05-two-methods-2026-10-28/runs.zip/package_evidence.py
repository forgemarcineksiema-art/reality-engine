"""Retain the actual run artifacts and their hashes; no engine conclusions."""
import hashlib
import json
import pathlib
import subprocess
import sys
import zipfile

root = pathlib.Path(__file__).resolve().parents[2]
runs = root / 'build/m05-two-methods'
destination = root / 'docs/verification/evidence/m05-two-methods-2026-10-28'
destination.mkdir(parents=True, exist_ok=False)


def digest(data):
    return hashlib.sha256(data).hexdigest()


entries = {}
with zipfile.ZipFile(destination / 'runs.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(runs.rglob('*')):
        if path.is_file() and path.suffix in ('.log', '.save', '.png', '.json', '.py'):
            data = path.read_bytes()
            name = path.relative_to(runs).as_posix()
            archive.writestr(name, data)
            entries[name] = {'bytes': len(data), 'sha256': digest(data)}

sys.path.insert(0, str(root / 'tools'))
from run_contrast_experiment import source_files
sources = [path.relative_to(root).as_posix() for path in source_files(root)]
with zipfile.ZipFile(destination / 'runs.zip', 'a', zipfile.ZIP_DEFLATED) as archive:
    for name in sources:
        data = (root / name).read_bytes()
        entry = 'source/' + name
        archive.writestr(entry, data)
        entries[entry] = {'bytes': len(data), 'sha256': digest(data)}
manifest = {
    'date': '2026-10-28',
    'verification_date': '2026-10-29',
    'base': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
    'branch': subprocess.check_output(['git', 'branch', '--show-current'], cwd=root, text=True).strip(),
    'sources': {name: digest((root / name).read_bytes()) for name in sources},
    'binaries': {name: digest((root / name).read_bytes()) for name in (
        'build/msvc/RelWithDebInfo/reality_traversal.exe',
        'build/msvc/RelWithDebInfo/reality_two_methods_tests.exe')},
    'archive': {'path': 'runs.zip', 'sha256': digest((destination / 'runs.zip').read_bytes()),
                'entries': entries},
    'limits': ['New-scene horizon changed from 600 to 1200 world ticks after retained failure.',
               'Historical M04 horizons and CTest20s unchanged.',
               'No human acceptance of the new scenario; no full-window Computer Use view.',
               'No repeat independent review after author corrections.'],
}
(destination / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
with zipfile.ZipFile(destination / 'runs.zip') as archive:
    assert archive.testzip() is None
    for name, record in entries.items():
        data = archive.read(name)
        assert len(data) == record['bytes'] and digest(data) == record['sha256'], name
print(f'PASS preserved and verified {len(entries)} artifacts')
